package com.company.hcl.service;

import java.util.ArrayList;
import java.util.DoubleSummaryStatistics;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import com.company.hcl.dto.EmployeeRequestDto;
import com.company.hcl.model.Employee;

public interface EmployeeService {

	void saveEmployee(EmployeeRequestDto employeeRequestDto);

	Iterable<Employee> getAllEmployeeDetails();

	void deleteEmployeeDetails(long id);

	void updateEmployeeDetails(long id, String type);

	ArrayList<HashMap<Object, Object>> getAllAggregateDetails();
}
