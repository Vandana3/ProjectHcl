package com.company.hcl.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.company.hcl.dto.EmployeeRequestDto;
import com.company.hcl.model.Employee;
import com.company.hcl.service.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	EmployeeService employeeService;

	@PostMapping("/employee")
	public void saveEmployee(@RequestBody EmployeeRequestDto employeeRequestDto) {
		employeeService.saveEmployee(employeeRequestDto);
	}

	@GetMapping("/employee")
	public Iterable<Employee> getAllEmployee() {
		return employeeService.getAllEmployeeDetails();
	}

	@DeleteMapping("/employee")
	public void deleteEmployee(@RequestParam("id") long id) {
		employeeService.deleteEmployeeDetails(id);
	}
	
	@GetMapping("/update")
	public void updateEmployee(@RequestParam("id") long id,@RequestParam("type") String type) {
		employeeService.updateEmployeeDetails(id,type);
	}
}
