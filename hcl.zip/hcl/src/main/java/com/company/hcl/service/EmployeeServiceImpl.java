package com.company.hcl.service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.DoubleSummaryStatistics;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.hcl.dto.EmployeeRequestDto;
import com.company.hcl.model.Employee;

import com.company.hcl.dao.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	@Autowired 
	EmployeeRepository employeeRepository;
	@Autowired
	ModelMapper modelMapper;
	@Override
	public void saveEmployee(EmployeeRequestDto employeeRequestDto) {
		
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		Employee employee = modelMapper.map(employeeRequestDto, Employee.class);
		employeeRepository.save(employee);
		
		
	}

	@Override
	public Iterable<Employee> getAllEmployeeDetails() {
		return employeeRepository.findAll();
	}
	
	@Override
	public void deleteEmployeeDetails(long id) {
		employeeRepository.deleteById(id);
	}

	@Override
	public void updateEmployeeDetails(long id, String type) {
		employeeRepository.updateEmployee(id,type);
		
	}

	@Override
	public ArrayList<HashMap<Object, Object>> getAllAggregateDetails() {
		
		List<Employee> employees=(List<Employee>) employeeRepository.findAll();
		 //Map<String, Optional<Employee>> sum = employees.stream().collect(
	                //Collectors.groupingBy(Employee::getType,Collectors.maxBy(Comparator.comparing(Employee::getSalary))) );
		//Map<String,Map<String,Double>> sum=employees.stream().collect(Collectors.groupingBy(Employee::getType,Collectors.groupingBy(Employee::getCity,Collectors.summingDouble(Employee::getSalary))));
		Map<String, Map<String, DoubleSummaryStatistics>> stats = employees.stream().collect(Collectors.groupingBy(Employee::getType,Collectors.groupingBy(Employee::getCity,
	            Collectors.summarizingDouble(Employee::getSalary))));
		ArrayList<HashMap<Object,Object>> list = new ArrayList<HashMap<Object,Object>>();
		
		for(String key1:stats.keySet()) {
			for(String key2:stats.get(key1).keySet()) {
				HashMap<Object,Object> map= new HashMap<Object,Object>();
				map.put("type",key1);
				map.put("city",key2);
				map.put("count",stats.get(key1).get(key2).getCount());
				map.put("max",stats.get(key1).get(key2).getMax());
				map.put("min",stats.get(key1).get(key2).getMin());
				map.put("average",stats.get(key1).get(key2).getAverage());
				map.put("sum",stats.get(key1).get(key2).getSum());
				list.add(map);
			}
		}
		Map<String, DoubleSummaryStatistics> statsOne = employees.stream().collect(Collectors.groupingBy(Employee::getCity,
	            Collectors.summarizingDouble(Employee::getSalary)));
		return list;
		
		//return list;
	}


	}

