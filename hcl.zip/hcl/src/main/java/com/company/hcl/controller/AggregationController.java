package com.company.hcl.controller;

import java.util.ArrayList;
import java.util.DoubleSummaryStatistics;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.company.hcl.model.Employee;
import com.company.hcl.service.EmployeeService;

@RestController
public class AggregationController {
	@Autowired
	EmployeeService employeeService;
	
	@GetMapping("/aggregation")
	public ArrayList<HashMap<Object, Object>> getAllEmployeeAggregates() {
		return employeeService.getAllAggregateDetails();
	}
}
