package com.company.hcl.dao;



import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.company.hcl.model.Employee;


@Repository
public interface EmployeeRepository extends CrudRepository<Employee,Long>{
	@Modifying
	@Transactional
	@Query("update Employee set type=:type where id=:id")
	void updateEmployee(@Param("id")long id, @Param("type")String type);

	

}
