import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import logo from './logo.svg';
import './App.css';
import data from './myjson.json';
const carList = data.description;
class Car extends Component {
	constructor() {
    super();
    this.state = {
      carCount: 0,
      carBrand:""
      
    };
  }
  displayDetail=()=>{
  	this.setState({carCount:this.state.carCount+1});
  	this.setState({carBrand:this.refs.mybrand.value});
  }
  
  render() {
  	
    return (
    	<div>
    	<p>Available brand</p>
    	<ul>	

                {carList.map(s => (<li>{s.name}</li>))}
        </ul>
    	<label>Enter car name</label>
    	<input type="text" ref="mybrand"/>
    	<button type="submit" onClick={this.displayDetail}>Buy</button>
    	<p>You bought: {this.state.carBrand}</p>
    	<p>Total no of cars sold: {this.state.carCount}</p>
    	
		</div>
    	);
  }
}

export default Car;

