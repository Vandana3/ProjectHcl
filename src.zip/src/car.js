import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import logo from './logo.svg';
import './App.css';

class Car extends Component {
  render() {
    return <h2>I am a Car!</h2>;
  }
}

export default Car;

