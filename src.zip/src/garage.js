
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import Car from './car';
class Garage extends Component {
  render() {
    return (
      <div >
      <h1>Carzzz</h1>
      <Car />
      </div>
    );
  }
}
export default Garage;