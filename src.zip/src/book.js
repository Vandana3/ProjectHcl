import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import './App.css';

import Home from './home.js';
import BookSearch from './bookSearch.js';
class Book extends Component{
	render() {
  	
    return (
    	<div className="book">
    	<p>{this.props.children}</p>
    	<img src="logo192.png"/>
		</div>
    	);
  }
}
export default Book;