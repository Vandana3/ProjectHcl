import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import bookData from './mybooks.json';
import Book from './book.js';
//const bookList=bookData.genre;
class BookSearch extends Component{
  render() {
  	var arr = [];
    var genre=this.props.bookProp;
    /*Object.keys(bookData).forEach(function(key) {
      arr.push(key);
    });
*/     
  if(genre=="mystery"){
    return (<div>{bookData.mystery.map((s) => (<Book>{s.name}</Book>))}</div>);
  }
  else if (genre=="fiction") {
    return (<div>{bookData.fiction.map((s) => (<Book>{s.name}</Book>))}</div>);
  }
  else{
    return(<div></div>);
  }
  }

}
export default BookSearch;