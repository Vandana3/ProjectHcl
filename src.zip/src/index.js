import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import Home from './home.js';
import BookSearch from './bookSearch.js';
import * as serviceWorker from './serviceWorker';

ReactDOM.render(<Home />, document.getElementById('mydiv'));
serviceWorker.unregister();
