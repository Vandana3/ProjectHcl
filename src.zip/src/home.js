import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import BookSearch from './bookSearch.js';
class Home extends Component{

	constructor() {
    super();
    this.state = {
      genre:""
    };
}
    saveGenre=()=>{
  	this.setState({genre:this.refs.bookGenre.value});
  }
    render() {
  	
    return (
    	<div>
    	<h1>BookTube</h1>
    	<p>Search For Books</p>
    	<label>Enter genre</label>
    	<input type="text" ref="bookGenre" onChange={this.saveGenre}/>
    	<button type="submit" onClick={this.saveGenre}>Search</button>
    	<BookSearch bookProp={this.state.genre}/>
    	
		</div>
    	);
  }
}
export default Home;